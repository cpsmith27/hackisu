(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['blaze-html-templates'] = {};

})();

//# sourceMappingURL=blaze-html-templates.js.map
