(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['barbatus:stars-rating'] = {};

})();

//# sourceMappingURL=barbatus_stars-rating.js.map
