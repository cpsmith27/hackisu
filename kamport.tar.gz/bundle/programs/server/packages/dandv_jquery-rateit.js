(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/dandv_jquery-rateit/packages/dandv_jquery-rateit.js      //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['dandv:jquery-rateit'] = {};

})();

//# sourceMappingURL=dandv_jquery-rateit.js.map
